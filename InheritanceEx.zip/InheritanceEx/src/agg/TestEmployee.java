package agg;

public class TestEmployee {
	
	public Employee setEmployeeData() {
		
		Employee employee = new Employee();
		
		employee.setEmpId(10101);
		employee.setEmpName("Ajay");
		
		Address address = new Address();
		
		address.setHouseNo(101);
		address.setSocietyName("Annexe");
		address.setAreaName("magarpatta city");
		address.setCity("Pune");
		address.setState("MH");
		
		employee.setAdd(address);
		
		return employee;
	}
	
	public static void main(String[] args) {
		TestEmployee te = new TestEmployee();
		Employee emp = te.setEmployeeData();
		
		System.out.println(emp.getEmpId());
		System.out.println(emp.getEmpName());
		
		System.out.println(emp.getAdd().getHouseNo());
		System.out.println(emp.getAdd().getAreaName());
		System.out.println(emp.getAdd().getState());
	}

}
