package agg;

public class Address {
	
	int houseNo;
	String societyName;
	String areaName;
	String city;
	String state;
	String country;
	
	public int getHouseNo() {
		return houseNo;
	}
	public void setHouseNo(int houseNo) {
		this.houseNo = houseNo;
	}
	public String getSocietyName() {
		return societyName;
	}
	public void setSocietyName(String societyName) {
		this.societyName = societyName;
	}
	public String getAreaName() {
		return areaName;
	}
	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	
//	public Address(int houseNo, String societyName, String areaName, String city, String state, String country) {
//		super();
//		this.houseNo = houseNo;
//		this.societyName = societyName;
//		this.areaName = areaName;
//		this.city = city;
//		this.state = state;
//		this.country = country;
//	}
	
	
	
	
	

}
