package heirachichal;

public class A {
	
	int a = 100;
	
	public void m1() {
		System.out.println("m1 called from class A");
	}

}
