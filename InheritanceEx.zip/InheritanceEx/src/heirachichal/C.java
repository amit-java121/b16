package heirachichal;

public class C extends A{
	int cc = 40;
	
	public void m4() {
		System.out.println("m4 called from class C");
	}

	
	public static void main(String[] args) {
		
		C c = new C();
		c.m1();
		c.m4();
	}
}
