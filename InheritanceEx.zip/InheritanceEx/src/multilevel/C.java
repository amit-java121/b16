package multilevel;

public class C extends B {
	
	int cc = 30;
	
	public void m3() {
		System.out.println("m3 called from class C");
	}
	
	
	public static void main(String[] args) {
		C c = new C();
		
	}

}
