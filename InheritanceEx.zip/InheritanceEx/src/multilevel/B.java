package multilevel;

public class B extends A{
	
	int bb = 50;
	
	public void m2() {
		
		System.out.println("m2 called from class B");
	}
	
	
	public static void main(String[] args) {
		
		B b = new B();
		b.m1();
		b.m2();
	}

}
