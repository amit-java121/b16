package rt;

public class UserModule {
	
	public Customer getUserDetails() {
		
		System.out.println("getUserDetails method called");
		Customer customer = new Customer(1000, "Ajay", "pune", 141441441);
		
		
		return customer;
	}
	
	
	public static void main(String[] args) {
		UserModule um = new UserModule();
		Customer cust = um.getUserDetails();
		System.out.println(cust.customerId);
		System.out.println(cust.customerName);
//		System.out.println(cust.customerAddress);
//		System.out.println(cust.contactNo);
	}

}
