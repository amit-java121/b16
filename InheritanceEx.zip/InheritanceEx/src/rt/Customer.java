package rt;

public class Customer {
	
	public int customerId;
	public String customerName;
	public String customerAddress;
	public int contactNo;
	
	public Customer(int customerId, String customerName, String customerAddress, int contactNo) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerAddress = customerAddress;
		this.contactNo = contactNo;
	}
	
	

}
