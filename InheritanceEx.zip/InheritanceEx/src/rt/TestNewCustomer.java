package rt;

public class TestNewCustomer {
	
	public NewCustomer getNewCustomerDetails() {
		
		NewCustomer newCustomer = new NewCustomer(1001, "Bijay", "mumbai", 18188881, 16616611);
		
		return newCustomer;
	}
	
	public static void main(String[] args) {
		TestNewCustomer tc = new TestNewCustomer();
		NewCustomer newCustomer = tc.getNewCustomerDetails();
		System.out.println(newCustomer.adhaarNo);
		System.out.println(newCustomer.customerAddress);
	}

}
