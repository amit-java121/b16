package rt;

public class NewCustomer extends Customer{

	public int adhaarNo;

	public NewCustomer(int customerId, String customerName, String customerAddress, int contactNo, int adhaarNo) {
		super(customerId, customerName, customerAddress, contactNo);
		this.adhaarNo = adhaarNo;
	}
	
	
	
}
