package com;

public class UserTest {

	
	public User setUserData() {
		User user = new User(1000, "Bijay", "mumbai");
		
		return user;
	}
	
	
	public static void main(String[] args) {
		
		UserTest ut = new UserTest();
		User user = ut.setUserData();
		
		System.out.println(user.getUserName());
		
		System.out.println(user.toString());
		
		
		
		
	}
}
