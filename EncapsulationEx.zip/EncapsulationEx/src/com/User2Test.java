package com;

public class User2Test {
	
	public static void main(String[] args) {
		User2 u2 = new User2(101, "Deepak", "pune");
		
		System.out.println(u2.toString());
		
		u2.setUserAddress("Nagpur");
		
		System.out.println(u2.toString());
	}

}
