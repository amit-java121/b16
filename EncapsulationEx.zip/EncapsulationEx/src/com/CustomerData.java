package com;

public class CustomerData {
	
	public Customer setCustomerData() {
		
		//Data prepare
		Customer customer = new Customer();
		
		customer.setCustomerId(1010);
		customer.setCustomerName("Ajay");
		customer.setAddress("pune");
		customer.setContactNumber(191992829);
		
		return customer;
	}

}
