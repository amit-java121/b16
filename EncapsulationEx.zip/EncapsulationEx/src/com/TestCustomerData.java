package com;

public class TestCustomerData {
	
	
	public Customer printData() {
		CustomerData cd = new CustomerData();
		Customer cust = cd.setCustomerData();
		
	   System.out.println(cust.getCustomerId());
//		System.out.println(cust.getCustomerName());
//		System.out.println(cust.getAddress());
//		System.out.println(cust.getContactNumber());
		
		//System.out.println(cust.toString());
		return cust;
	}
	
	public static void main(String[] args) {
		TestCustomerData tcd = new TestCustomerData();
		Customer customer = tcd.printData();
		
		System.out.println(customer.toString());
	}

}
