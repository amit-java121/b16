package practice;

public class TestA {
	
	
	public static void main(String[] args) {
	
		A a = new A();
//		boolean flag = a.getUserName("Xpertit");
//		//System.out.println(flag);
//		
//		
//		boolean flag2= A.getUserPass("Xpertit");
//		
//		if(flag && flag2) {
//			System.out.println("u r authorized person::::");
//		}else {
//			System.out.println("u r not authorized person::::");
//		}
		//System.out.println(flag2);
		//System.out.println(A.getUserPass("abcd"));
		
		
		///////////////////////
		String msg = a.verifyUserCredentials("amit", "amit");
		System.out.println(msg);
	}

}
