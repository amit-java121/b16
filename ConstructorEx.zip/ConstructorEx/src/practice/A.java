package practice;

public class A {
	
	public boolean getUserName(String userName) {
		// == 
		if(userName.equalsIgnoreCase("xpertit")) {
			return true;
		}else {
			return false;
		}
		
	}
	
	
	public static boolean getUserPass(String userPass) {
		// == 
		if(userPass.equalsIgnoreCase("xpertit")) {
			return true;
		}else {
			return false;
		}
		
	}
	
	public String verifyUserCredentials(String userName,String userPass) {
		
		if(userName.equalsIgnoreCase("amit") && userPass.equalsIgnoreCase("amit")) {
			return "u r authorized:::";
		}else {
			return "u r not authorized::";
		}
		
	}

}
