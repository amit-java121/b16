package com;

public class ConstEx2 {
	
	int age;
	String name;

	public ConstEx2() {
		this("Ajay");
		System.out.println("default const::");
	}

	public ConstEx2(int age, String name) {
		this.age= age;
		this.name = name;
	}

	public ConstEx2(String stName) {
		this(20,stName);
		System.out.println("one param");
		
		//name = stName;
	}
	
	
	public static void main(String[] args) {
		ConstEx2 ce = new ConstEx2(20,"Ajay");
		
		ConstEx2 ce2 = new ConstEx2();
		 ce2 = ce;
		
		System.out.println(ce2.name);
		System.out.println(ce2.age);
		
	}
}
