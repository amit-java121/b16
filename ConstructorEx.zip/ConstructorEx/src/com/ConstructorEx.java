package com;

public class ConstructorEx {
	
	int age;
	String name;
	
	public ConstructorEx() {
		System.out.println("default constructor::");
		
	}
//	
	public ConstructorEx(int ag,String nam) {
		System.out.println("param constructor::");
		age = ag;
		name = nam;
	}
	
	public static void main(String[] args) {
		
		ConstructorEx ce = new ConstructorEx(25,"xperit");
		
		System.out.println(ce.age);
		System.out.println(ce.name);
		
		ConstructorEx ce2 = new ConstructorEx(30,"xperit hadapsar");
		System.out.println(ce2.age);
		System.out.println(ce2.name);
		
		ConstructorEx ce3 = new ConstructorEx();
		
	}


}
