package com.it.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.it.service.IUserService;

@RestController
public class UserController {
	
	@Autowired
	IUserService userService;
	
	@GetMapping("/login")
	public String userLogin(@RequestParam("userName") String username,@RequestParam("userPass") String userpass) {
		System.out.println("user name "+username+" user pass "+userpass);
		
		userService.checkUserCredentials(username,userpass);
		
		return "you are logged in successfully with credentials : user name: "+username+" user pass: "+userpass;
	}

}
