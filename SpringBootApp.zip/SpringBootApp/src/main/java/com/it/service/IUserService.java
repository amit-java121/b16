package com.it.service;

public interface IUserService {

	void checkUserCredentials(String username, String userpass);

}
