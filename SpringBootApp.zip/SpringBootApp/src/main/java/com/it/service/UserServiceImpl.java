package com.it.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.it.dao.DaoRepository;
import com.it.model.User;

@Service
public class UserServiceImpl implements IUserService{
	
	@Autowired
	DaoRepository repository;
	

	@Override
	public void checkUserCredentials(String username, String userpass) {

		User user = repository.findByUserEmail(username);
		System.out.println("user from user service impl "+user.toString());
		
	}

}
