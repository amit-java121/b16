package springboot.service;

import springboot.model.Customer;
import springboot.model.NewCustomer;

public interface CustomerService {

	Customer verifyCustomerCredentials(String username, String passowrd);

	Customer saveCustomer(Customer customer);

	Customer getCustomerDataById(Integer id);

	boolean deleteCustomerDataById(Integer id);

	void updateCustomerDetails(Customer customer);

	NewCustomer placeOrder(NewCustomer newCustomer);

}
