package springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import springboot.dao.CustomerRepository;
import springboot.dao.NewCustomerRepository;
import springboot.model.Customer;
import springboot.model.NewCustomer;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService{
	
	@Autowired
	CustomerRepository repository;
	
	@Autowired
	NewCustomerRepository newCustomerRepository;

	@Override
	public Customer verifyCustomerCredentials(String username, String passowrd) {
		
		Customer customer = repository.findUserByEmail(username);
		return customer;
	}

	@Override
	public Customer saveCustomer(Customer customer) {

		Customer cust = repository.save(customer);
		
		return cust;
	}

	@Override
	public Customer getCustomerDataById(Integer id) {
		
		Customer customer = repository.getById(id);
		return customer;
	}

	@Override
	public boolean deleteCustomerDataById(Integer id) {
		boolean flag = false;
		try {
			repository.deleteById(id);
			flag =true;
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return flag;
	}

	@Override
	public void updateCustomerDetails(Customer customer) {
		
//		Customer cust = repository.getById(customer.getUserId());
//		
//		cust.setUserId(customer.getUserId());
//		cust.setUserName(customer.getUserName());
//		cust.setUserEmail(customer.getUserEmail());
//		cust.setMobileNumber(customer.getMobileNumber());
//		cust.setCountry(customer.getCountry());
		
		repository.save(customer);
		
		
	}

	@Override
	public NewCustomer placeOrder(NewCustomer newCustomer) {
		// TODO Auto-generated method stub
		
		return newCustomerRepository.save(newCustomer);
	}

}
