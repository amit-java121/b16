package transaction;

public class Transation extends Thread {
	
	 static int  balance = 2000;
	
	@Override
	public void run() {
		for(int i=0; i<10; i++) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			withdraw(200);
		}
	}
	
	private static synchronized void withdraw(int amt) {
		
		System.out.println("Thread trying to withdraw: "+Thread.currentThread().getName());
		if(balance > amt) {
			balance = balance - amt;
			System.out.println(Thread.currentThread().getName()  +"  "+balance);
		}else {
			System.out.println(" no suffcient balance::");
		}
		
	}
	

}
