package transaction;

public class TriggerTransaction {
	
	public static void main(String[] args) {
		
		Transation tr = new Transation();
		tr.start();
		tr.setName("HDFC ATM");
		
		Transation tr2 = new Transation();
		tr2.start();
		tr2.setName("HDFC BANK");
		
		
	}

}
