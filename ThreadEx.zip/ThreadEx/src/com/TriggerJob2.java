package com;

public class TriggerJob2 {
	
	public static void main(String[] args) {
		
		Job2 job2 = new Job2();
		Thread th = new Thread(job2);
		th.start();
		
	}

}
