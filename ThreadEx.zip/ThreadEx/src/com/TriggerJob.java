package com;

public class TriggerJob {
	
	public static void main(String[] args) throws InterruptedException {
		
		System.out.println("before first loop "+Thread.currentThread().getName());
		
		for(int i=0;i<10; i++) {
			System.out.println(i);
		}
		
		Job job = new Job();
		job.start();
		job.setName("HDFC Bank");
		//job.join();
		
		
//		Job job1 = new Job();
//		job1.start();
		
		System.out.println("before second loop: "+Thread.currentThread().getName());
		for(int i=20;i<30; i++) {
			System.out.println(i);
		}
		
		
		
	}

}
