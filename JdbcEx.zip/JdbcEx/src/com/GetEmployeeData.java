package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class GetEmployeeData {

	public ArrayList<Employee> getEmpData() {
		
		ArrayList<Employee> empList = new ArrayList<>();

		try {

			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("step 1");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b16", "root", "root");
			System.out.println("step 2");
			Statement stmt = con.createStatement();
			System.out.println("step 3");
			ResultSet rs = stmt.executeQuery("select * from employee");
			System.out.println("step 4");
			
			
			while (rs.next()) {
				Employee emp = new Employee();
				emp.setEmpId(rs.getInt("empId"));
				emp.setEmpName(rs.getString("emp_name"));
				emp.setEmpAddress(rs.getString("emp_address"));
				emp.setEmpPass(rs.getString("emp_pass"));
				emp.setGender(rs.getString("emp_gender"));
				emp.setEmpContact(rs.getLong("emp_contact"));
				//System.out.println(rs.getString("empId"));
				//System.out.println(rs.getString("emp_name"));
				//System.out.println(rs.getString("emp_address"));
				//System.out.println(rs.getString("emp_gender"));
				//System.out.println(rs.getString("emp_contact"));
				//System.out.println(rs.getString("emp_pass"));
				empList.add(emp);
			}
			

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return empList;
	}

}
