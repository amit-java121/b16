package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;

public class SaveEmployeeData {
	
	public Employee prepareEmployeeData() {
		
		Employee employee = new Employee();
		//employee.setEmpId(103);
		employee.setEmpName("Sunil");
		employee.setEmpAddress("pune");
		employee.setEmpPass("abc@123");
		employee.setEmpContact(191919919);
		employee.setGender("male");
		
		return employee;
		
	}
	
	public boolean saveEmployeeDetails() {
		boolean flag = false;
		Employee emp = prepareEmployeeData();
		
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		System.out.println("step 1");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b16","root","root");
		System.out.println("step 2");
		Statement stmt = con.createStatement();
		System.out.println("step 3");
		int i = stmt.executeUpdate("insert into employee (emp_name,emp_address,emp_gender,emp_contact,emp_pass) values('"+emp.getEmpName()+"','"+emp.getEmpAddress()+"','"+emp.getGender()+"','"+emp.getEmpContact()+"','"+emp.getEmpPass()+"')");
		 if(i > 0) {
			 flag =true;
		 }
		 
		}catch(Exception e) {
			flag = false;
			e.printStackTrace();
		}
		
		return flag;
	}
	
	
	
	
	public static boolean saveListOfEmpDetails(List<Employee> empList) {
		boolean flag = false;
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		System.out.println("step 1");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b16","root","root");
		System.out.println("step 2");
		Statement stmt = con.createStatement();
		System.out.println("step 3");
		for(int i=0; i< empList.size(); i++) {
		Employee emp = empList.get(i);
	    stmt.executeUpdate("insert into employee (emp_name,emp_address,emp_gender,emp_contact,emp_pass) values('"+emp.getEmpName()+"','"+emp.getEmpAddress()+"','"+emp.getGender()+"','"+emp.getEmpContact()+"','"+emp.getEmpPass()+"')");
		
		}
		 
		}catch(Exception e) {
			flag = false;
			e.printStackTrace();
		}
		
		return flag;
	}
	
	
	public static boolean deleteEmpDetails(int id) {
		boolean flag = false;
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		System.out.println("step 1");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b16","root","root");
		System.out.println("step 2");
		Statement stmt = con.createStatement();
		System.out.println("step 3");
	
	    int i= stmt.executeUpdate("delete from employee where empId ="+id);
		System.out.println(i);
		 
		}catch(Exception e) {
			flag = false;
			e.printStackTrace();
		}
		
		return flag;
	}
	
	
	public static boolean updateEmpDetails(Employee emp) {
		boolean flag = false;
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		System.out.println("step 1");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b16","root","root");
		System.out.println("step 2");
		Statement stmt = con.createStatement();
		System.out.println("step 3");
	
	    int i= stmt.executeUpdate("update employee set emp_name='"+emp.getEmpName()+"',emp_address='"+emp.getEmpAddress()+"' where empId="+emp.getEmpId());
		System.out.println(i);
		 
		}catch(Exception e) {
			flag = false;
			e.printStackTrace();
		}
		
		return flag;
	}
	
	
	//using prepared statement
	public static boolean saveListOfEmp(List<Employee> empList) {
		boolean flag = false;
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		System.out.println("step 1");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b16","root","root");
		System.out.println("step 2");
		PreparedStatement pstmt = con.prepareStatement("insert into employee (emp_name,emp_address,emp_gender,emp_contact,emp_pass) values (?,?,?,?,?)");
		System.out.println("step 3");
		for(int i=0; i< empList.size(); i++) {
			pstmt.setString(1, empList.get(i).getEmpName());
			pstmt.setString(2, empList.get(i).getEmpAddress());
			pstmt.setString(3, empList.get(i).getGender());
			pstmt.setLong(4, empList.get(i).getEmpContact());
			pstmt.setString(5, empList.get(i).getEmpPass());
			
			int ii= pstmt.executeUpdate();
			System.out.println(ii);
		}
//		for(int i=0; i< empList.size(); i++) {
//		Employee emp = empList.get(i);
//	    stmt.executeUpdate("insert into employee (emp_name,emp_address,emp_gender,emp_contact,emp_pass) values('"+emp.getEmpName()+"','"+emp.getEmpAddress()+"','"+emp.getGender()+"','"+emp.getEmpContact()+"','"+emp.getEmpPass()+"')");
//		
//		}
		 
		}catch(Exception e) {
			flag = false;
			e.printStackTrace();
		}
		
		return flag;
	}
	
	
	public static void main(String[] args) {
		SaveEmployeeData sed = new SaveEmployeeData();
		
		if(sed.saveEmployeeDetails()) {
			System.out.println("Employee details saved successfully");
		}else {
			System.out.println("Employee details is not saved successfully please try again::");
		}
		
	}

}
