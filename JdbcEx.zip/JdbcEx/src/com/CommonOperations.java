package com;

import java.util.ArrayList;

public class CommonOperations {
	
	public void printEmpData() {
		GetEmployeeData ged = new GetEmployeeData();
		ArrayList<Employee> employeeList = ged.getEmpData();
		System.out.println(employeeList.toString());
	}
	
	public static void main(String[] args) {
		CommonOperations op = new CommonOperations();
		op.printEmpData();
	}

}
