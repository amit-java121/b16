package com;

import java.util.ArrayList;
import java.util.List;

public class CommonOperations {
	
	public void printEmpData() {
		GetEmployeeData ged = new GetEmployeeData();
		ArrayList<Employee> employeeList = ged.getEmpData();
		System.out.println(employeeList.toString());
	}
	
	public void saveListOfEmployee() {
		
		Employee employee = new Employee();
		employee.setEmpName("Sunil");
		employee.setEmpAddress("pune");
		employee.setEmpPass("abc@123");
		employee.setEmpContact(191919919);
		employee.setGender("male");
		
		Employee employee1 = new Employee();
		employee1.setEmpName("Sunil");
		employee1.setEmpAddress("pune");
		employee1.setEmpPass("abc@123");
		employee1.setEmpContact(191919919);
		employee1.setGender("male");
		
		Employee employee2 = new Employee();
		employee2.setEmpName("Sunil");
		employee2.setEmpAddress("pune");
		employee2.setEmpPass("abc@123");
		employee2.setEmpContact(191919919);
		employee2.setGender("male");
		
		List<Employee> listOfEmp = new ArrayList<>();
		listOfEmp.add(employee);
		listOfEmp.add(employee1);
		listOfEmp.add(employee2);
		
		SaveEmployeeData.saveListOfEmpDetails(listOfEmp);
		
	}
	
	
	public void deleteEmployee() {
		SaveEmployeeData.deleteEmpDetails(102);
	}
	
	public void updateEmployeeDetails() {
		Employee employee = new Employee();
		employee.setEmpName("Promod");
		employee.setEmpAddress("mumbai");
		employee.setEmpId(104);
		
		SaveEmployeeData.updateEmpDetails(employee);
	}
	
	public void saveUsingPrepared() {
		Employee employee = new Employee();
		employee.setEmpName("Promod");
		employee.setEmpAddress("pune");
		employee.setEmpPass("abc@123");
		employee.setEmpContact(191919919);
		employee.setGender("male");
		
		Employee employee1 = new Employee();
		employee1.setEmpName("xpertit");
		employee1.setEmpAddress("nagpur");
		employee1.setEmpPass("abc@123");
		employee1.setEmpContact(191919919);
		employee1.setGender("male");
		
		List<Employee> listOfEmp = new ArrayList<>();
		listOfEmp.add(employee);
		listOfEmp.add(employee1);
		
		SaveEmployeeData.saveListOfEmp(listOfEmp);
	}
	
	public static void main(String[] args) {
		CommonOperations op = new CommonOperations();
		//op.printEmpData();
		//op.saveListOfEmployee();
		//op.deleteEmployee();
		//op.updateEmployeeDetails();
		op.saveUsingPrepared();
	}

}
