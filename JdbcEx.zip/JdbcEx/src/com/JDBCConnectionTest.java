package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class JDBCConnectionTest {
	
	public static void main(String[] args) {
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("step 1");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b16","root","root");
			System.out.println("step 2");
			Statement stmt = con.createStatement();
			System.out.println("step 3");
			 ResultSet rs = stmt.executeQuery("select * from employee");
			 System.out.println("step 4");
			 while(rs.next()) {
				 System.out.println(rs.getString("empId"));
				 System.out.println(rs.getString("emp_name"));
				 System.out.println(rs.getString("emp_address"));
				 System.out.println(rs.getString("emp_gender"));
				 System.out.println(rs.getString("emp_contact"));
				 System.out.println(rs.getString("emp_pass"));
			 }
			
			
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
