package it;

public class ThrowsWithUncheckedEx {
	
	public void test() throws ArithmeticException{
		
		System.out.println("before exception::");
		int div = 10/0;
		System.out.println("after exception");
		
	}
	
	public void test2() {
		try {
		test();
		}catch(ArithmeticException ae) {
			System.out.println("arithmetic "+ae);
		}
	}
	
	public static void main(String[] args) {
		ThrowsWithUncheckedEx twu = new ThrowsWithUncheckedEx();
		twu.test2();
	}

}
