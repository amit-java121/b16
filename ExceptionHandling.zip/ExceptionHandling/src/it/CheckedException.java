package it;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class CheckedException {
	
	public void readDataFromFile() {
		try {
		File f = new File("C://kakakak");
		FileOutputStream fos = new FileOutputStream(f);
			//Database connection code
			
		}catch(FileNotFoundException fn) {
			System.out.println(fn);
		}
		
	}
	
	
	public void readDataFromDB() throws ClassNotFoundException {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
	}
	public static void main(String[] args) {
		CheckedException ce = new CheckedException();
		try {
			ce.readDataFromDB();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
