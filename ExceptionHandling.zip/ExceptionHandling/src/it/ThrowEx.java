package it;

public class ThrowEx {
	
	public void test(int marks) throws Exception{
		
		if(marks < 30) {
			throw new ArithmeticException("you are failed:::");
		}else {
			System.out.println("you are passed:::");
		}
		
	}
	
	public void test2() throws Exception {
		test(20);
	}
	
	public static void main(String[] args) {
		ThrowEx te = new ThrowEx();
		try {
		te.test2();
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
