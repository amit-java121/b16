package it.custom;

public class TestCustomException {
	
	public String verifyUser(int userId,String userName) throws UserNotFoundException{
		
		if(userId==100 && userName.equalsIgnoreCase("expert")) {
			return "this valid user";
		}else {
			throw new UserNotFoundException(402, "user does not exist");
		}
		
		
	}
	
	public static void main(String[] args) {
		TestCustomException tc = new TestCustomException();
		
		try {
			
			String resposne = tc.verifyUser(100, "xpert");
			System.out.println(resposne);
			
		} catch (UserNotFoundException e) {
			System.out.println(e.getErrorCode());
			System.out.println(e.getErrorMessage());
		}
	}

}
