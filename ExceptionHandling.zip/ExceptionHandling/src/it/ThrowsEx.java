package it;

public class ThrowsEx {
	
	public void test() throws ClassNotFoundException {
		
		Class.forName("");
		
	}
	
	public void test2() throws ClassNotFoundException {
		test();	
	}
	
	public static void main(String[] args) {
		ThrowsEx te = new ThrowsEx();
		try {
			te.test2();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
