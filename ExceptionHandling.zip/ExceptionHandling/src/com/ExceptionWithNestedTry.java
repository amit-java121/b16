package com;

public class ExceptionWithNestedTry {

	public int division(int a, int b) {
		System.out.println("add function called");
		int div = 0;
		try {
			String name = "";
			System.out.println(name.equals("xperit"));

				try {
	
					div = a / b;
					System.out.println(div);
	
				} catch (ArithmeticException ae) {
					System.out.println("first catch block executed::");
					System.out.println(ae);
				}
		} catch (NullPointerException ae) {
			System.out.println("second catch block executed::");
			System.out.println(ae);
		}

		finally {
			System.out.println("finally block executed:::");
		}

		int addition = div + 100;

		System.out.println(addition);

		return addition;
	}

	public static void main(String[] args) {
		ExceptionWithNestedTry ewt = new ExceptionWithNestedTry();
		ewt.division(10, 0);
	}

}
