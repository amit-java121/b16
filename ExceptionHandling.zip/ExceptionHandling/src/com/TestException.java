package com;

public class TestException {
	
	public static void main(String[] args) {
		NetstedTryCatchEx ewt = new NetstedTryCatchEx();
		String output= ewt.division(10, 2);
		System.out.println("final output::"+output);
	}

}
