package com;

public class NetstedTryCatchEx {
	
	public String division(int a, int b) {
		System.out.println("add function called");
		int div = 0;
		try {
			
			//int[] array = {10,20,30};
			//System.out.println(array[3]);
			
			//String name = null;
			//System.out.println(name.equals("xperit"));

			div = a / b;
			System.out.println(div);
	
		} catch (ArithmeticException ae) {
			System.out.println("ArithmeticException catch block executed::");
			System.out.println(ae);
			return "You can not devide by zero. please try with other number";
		}catch(NullPointerException np) {
			System.out.println("NullPointerException catch block executed::");
			return "Name should not be null";
		}catch(Exception e) {
			System.out.println("Exception catch block executed::");
		}
		
		finally {
			System.out.println("finally block executed:::");
		}

		int addition = div + 100;

		System.out.println(addition);

		return String.valueOf(addition);
	}

	


}
