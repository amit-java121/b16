
public class StringEx {
	
	public static void main(String[] args) {
		
		String str ="hello";
		String str2 = "hi";
		String str4 = "hello";
		
		String str3  =  new String("hello");
		
		//System.out.println(str);
		//str="hi";
		//System.out.println(str);
		
		
		//String str3 = str.concat("hi");
		//System.out.println(str3);
		
		System.out.println(str.equals(str4));//true
		System.out.println(str.equals(str2));//false
		System.out.println(str==str4);//true
		System.out.println(str == str2);//false

		System.out.println(str.equals(str3));//true
		System.out.println(str == str3);//false
		
	}

}
