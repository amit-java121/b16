package com;

public class StringEx {
	
	public static void main(String[] args) {
		
		//StringEx stringEx = new StringEx();
		
		String str ="Hello";
		String st = new String("xpertit");
		
		String str1 ="Hello";
		String st1 = new String("xpertit");
		
		
		//System.out.println(str.equals(str1));
		System.out.println(str == str1);
		
		System.out.println(st.equals(st1));
		System.out.println(st == st1);

		
	}

}
