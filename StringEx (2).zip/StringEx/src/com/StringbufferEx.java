package com;

public class StringbufferEx {
	
	public static void main(String[] args) {
		
		StringBuffer sb = new StringBuffer(" hello  xpertit");
		//sb.append(" xpertit");
		
//		System.out.println(sb);
//		
//		StringBuffer sb1 = new StringBuffer();
//		
//		sb1.ensureCapacity(20);
//		System.out.println(sb1.capacity());
//		
//		System.out.println(sb.delete(0, 5));
//		
//		System.out.println(sb.substring(0, 0));
//		
//		String str ="";
//		System.out.println(str.substring(0, 0));
		 
		sb.trimToSize();
		System.out.println();
		
		
		StringBuilder sbd = new StringBuilder();
		
		
	}

}
