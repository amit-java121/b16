package com;

public class TestStringFunctions {

	public static void main(String[] args) {
		
		String str ="hello,this,is,java,classes";
		String str1 = "ll";

		//System.out.println(str.contains(str1));
		//System.out.println(str.isBlank());
		//System.out.println(str.isEmpty());
		//System.out.println(str.endsWith("o"));
		
		//System.out.println(str.length());
		
		//System.out.println(str.repeat(2));
		//System.out.println(str.substring(2));
		//System.out.println(str.substring(1, 5));
		
		//System.out.println(str.toUpperCase());
		
		//System.out.println(str.getBytes());
		
		String[] strArray = str.split(",");
		System.out.println(strArray.length);
		
		for(String array:strArray) {
			System.out.println(array);
		}
		
//		for(int i=0;i<strArray.length;i++) {
//			System.out.println(strArray[i]);
//		}
		
		
	}
}
