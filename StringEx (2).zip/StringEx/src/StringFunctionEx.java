
public class StringFunctionEx {
	
	public static void main(String[] args) {
		
		String str = "hello,Ajay,this,is,my,institute";
		
		//institute my is this Ajay hello
		
		//String str2 = str.concat(" Ajay");
		//System.out.println(str2);
		
		
		//System.out.println(str.charAt(4));
		//System.out.println(str.contains("ll"));
		//System.out.println(str.contentEquals("hello"));
		//System.out.println(str.endsWith("h"));
		//System.out.println(str.equalsIgnoreCase("Hello"));
		//System.out.println(str.indexOf("l"));
		//System.out.println(str.isEmpty());
		//System.out.println(str.length());
		//System.out.println(str.replace("ll", "AA"));
		//System.out.println(str.substring(1, 4));
		//System.out.println(str.toUpperCase());
		//System.out.println(str.toLowerCase());
		String[] strArray = str.split(",");
//		
//		for(int i=0;i<strArray.length;i++) {
//			System.out.print(strArray[i]+" ");
//		}
		
//		for(int i=strArray.length-1;i>=0;i--) {
//			System.out.print(strArray[i]+" ");	
//		}
		String name = " Ajay ";
		System.out.println(name.equalsIgnoreCase("ajay"));
		System.out.println(name.trim());
		
	}

}
