
public class StringBufferEx {
	
	public static void main(String[] args) {
		
		//StringBuffer sb = new StringBuffer("abc");
		//sb.append("hi");
		//System.out.println(sb);
		StringBuffer sb2 = new StringBuffer("hello");
//		String str = "hello";
//		String str2 = str.concat("hi");
//		System.out.println(str);
//		System.out.println(str2);
		
		
		//System.out.println(sb.capacity());
		//System.out.println(sb2.compareTo(sb2));
		//System.out.println(sb2.delete(1, 2));
		//System.out.println(sb2.reverse());
		System.out.println(sb2.insert(1, "LLL"));
		
	}

}
