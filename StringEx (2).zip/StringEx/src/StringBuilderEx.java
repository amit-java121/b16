
public class StringBuilderEx {
	
	public static void main(String[] args) {
		
		StringBuilder sb = new StringBuilder("hello");
		sb.append("hi");
		System.out.println(sb.reverse());
	}

}
