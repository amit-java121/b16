package com;

public class ThisEx {
	
	int age =25;
	
	public ThisEx() {
		this(10);
//		int aa = this.age+20;
//		
//		System.out.println(this.age);
	}
	
	public ThisEx(int a) {
		System.out.println("param const:::");
	}
	
	public void test() {
//		ThisEx obj = test2();
//		System.out.println(obj);
		test3(this);
	}
	
	public ThisEx test2() {
		
		return this;
	}
	
	public void test3(ThisEx obj) {
		System.out.println(obj);
		
	}
	
	
	public static void main(String[] args) {
		ThisEx te = new ThisEx();
		System.out.println("te object: "+te);
		te.test();
		
		ThisEx te2 = new ThisEx(100);
	}

}
