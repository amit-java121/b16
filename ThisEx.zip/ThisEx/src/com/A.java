package com;

public class A {
	
	String name = "xpertit";
	
	public void m1() {
		System.out.println("m1 called from class A");
	}
	
	public A() {
		System.out.println("const called from class A");
	}

}
