
public class StringFunctionEx {
	
	public static void main(String[] args) {
		
		String str = "hello";
		
		//String str2 = str.concat(" Ajay");
		//System.out.println(str2);
		
		
		//System.out.println(str.charAt(4));
		//System.out.println(str.contains("ll"));
		//System.out.println(str.contentEquals("hello"));
		//System.out.println(str.endsWith("h"));
		//System.out.println(str.equalsIgnoreCase("Hello"));
		System.out.println(str.indexOf("l"));
	}

}
