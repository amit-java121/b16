package com.it.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.it.dao.ILoginDao;
import com.it.model.User;
@Service
@Transactional
public class LoginServiceImpl implements ILoginService{
	
	@Autowired
	ILoginDao loginDao;

	@Override
	public boolean verifyUser(String userEmail, String password) {
	
		System.out.println("service method called");
		User user = loginDao.getUserCredentials(userEmail);
		
		if(user.getUserEmail().equals(userEmail) && user.getUserPass().equals(password)) {
			return true;
		}
		
		return false;
	}

	@Override
	public void saveUserData(User user) {
	
		loginDao.saveUserData(user);
		
	}

	@Override
	public List<User> getUserData() {
		// TODO Auto-generated method stub
		return loginDao.getListOfUser();
	}

}
