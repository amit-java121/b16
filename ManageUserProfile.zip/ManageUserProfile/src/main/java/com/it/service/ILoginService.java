package com.it.service;

import java.util.List;

import com.it.model.User;

public interface ILoginService {

	boolean verifyUser(String username, String password);

	String saveUserData(User user);

	List<User> getUserData();

	boolean deleteUser(int id);

	User getUserById(int id);

}
