package com.it.service;

import java.util.List;

import com.it.model.User;

public interface ILoginService {

	boolean verifyUser(String username, String password);

	void saveUserData(User user);

	List<User> getUserData();

}
