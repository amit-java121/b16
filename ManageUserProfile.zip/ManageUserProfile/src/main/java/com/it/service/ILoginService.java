package com.it.service;

public interface ILoginService {

	void verifyUser(String username, String password);

}
