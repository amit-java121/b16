package com.it.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.it.service.ILoginService;

@Controller
public class UserController {
	
	@Autowired
	ILoginService loginService;
	
	@GetMapping("/")
	public String homePage() {
		System.out.println("home page method called");
		return "home";
	}
	
	@GetMapping("/login")
	public void login(@RequestParam("userName") String username,@RequestParam("password") String password) {
		System.out.println("login method called::"+username+" "+password);
		loginService.verifyUser(username,password);
		
	}

}
