package com.it.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.it.model.User;
import com.it.service.ILoginService;

@Controller
public class UserController {
	
	@Autowired
	ILoginService loginService;
	
	@GetMapping("/")
	public String homePage() {
		System.out.println("home page method called");
		return "home";
	}
	
	@GetMapping("/login")
	public String login(@RequestParam("userName") String username,@RequestParam("password") String password,Model model) {
		System.out.println("login method called::"+username+" "+password);
		boolean flag = loginService.verifyUser(username,password);
		if(flag) {
			
			return "redirect:/getUser";
		}
		model.addAttribute("msg", "Your username and password is incorrect. Please try again!");
		return "home";
		
	}
	
	@GetMapping("/register")
	public ModelAndView userRegisterationPage() {
		System.out.println("userRegisterationPage::");
		User user = new User();
		ModelAndView model = new ModelAndView("userForm","user", user);
		
		return model;
	}
	
	@PostMapping("/save")
	public void saveUserDetails(@ModelAttribute User user) {
		System.out.println(user.toString());
		loginService.saveUserData(user);
	}
	
	@GetMapping("/getUser")
	public String getUserData(Model model) {
		
		List<User> userList = loginService.getUserData();
		System.out.println(userList.toString());
		model.addAttribute("list", userList);
		return "userList";
	}
	

}
