package com.it.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.it.model.User;
import com.it.service.ILoginService;

@Controller
public class UserController {
	
	@Autowired
	ILoginService loginService;
	
	@GetMapping("/")
	public String homePage() {
		System.out.println("home page method called");
		return "home";
	}
	
	@GetMapping("/login")
	public String login(@RequestParam("userName") String username,@RequestParam("password") String password,Model model) {
		System.out.println("login method called::"+username+" "+password);
		boolean flag = loginService.verifyUser(username,password);
		if(flag) {
			
			return "redirect:/getUser?msg=";
		}
		model.addAttribute("msg", "Your username and password is incorrect. Please try again!");
		return "home";
		
	}
	
	@GetMapping("/register")
	public ModelAndView userRegisterationPage(@RequestParam("msg") String msg) {
		System.out.println("userRegisterationPage::");
		User user = new User();
		ModelAndView model = new ModelAndView("userForm","user", user);
		model.addObject("message", msg);
		return model;
	}
	
	@PostMapping("/save")
	public String saveUserDetails(@ModelAttribute User user) {
		System.out.println(user.toString());
		String msg = loginService.saveUserData(user);
		if(msg.equalsIgnoreCase("save")) {
			return "home";
		}else if(msg.equalsIgnoreCase("update")) {
			return "redirect:/getUser?msg=Record updated successfully";
		}else if(msg.equalsIgnoreCase("saveerror")){
			return "redirect:/register?msg=Please try to save again!";
		}
		return "redirect:/update?msg=Please try to update again!";
	}
	
	@GetMapping("/getUser")
	public String getUserData(@RequestParam("msg") String msg, Model model) {
		
		List<User> userList = loginService.getUserData();
		System.out.println(userList.toString());
		model.addAttribute("list", userList);
		model.addAttribute("message", msg);
		return "userList";
	}
	
	@GetMapping("/delete")
	public String deleteUser(@RequestParam("id") int id) {
		System.out.println("id "+id);
		boolean flag = loginService.deleteUser(id);
		if(flag) {
			return "redirect:/getUser?msg=User record deleted successfully!!";
		}
		return "redirect:/getUser?msg=User record is not deleted. Please try again!!";
		
	}
	
	@GetMapping("/update")
	public ModelAndView getUserData(@RequestParam("idd") int id,@RequestParam("msg") String msg) {
		System.out.println("id "+id);
		User user= loginService.getUserById(id);
		ModelAndView model = new ModelAndView("updateForm","user", user);
		model.addObject("message", msg);
		return model;
	}
	
}
