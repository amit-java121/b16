package com.it.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.it.model.User;

@Repository
public class LoginDaoImpl implements ILoginDao{
	
	@Autowired
	SessionFactory sessionFactory;

	@Override
	public User getUserCredentials(String username) {

		System.out.println("login dao impl "+username);
		
		Session session = sessionFactory.openSession();
		
		Query query = session.createQuery("from User where userEmail=:email");
		
		User user = (User)query.setParameter("email", username).getSingleResult();
		
		System.out.println(user.toString());
		
		return user;
		
	}

	@Override
	public void saveUserData(User user) {

		Session session = sessionFactory.getCurrentSession();
		session.save(user);
		
	}

	@Override
	public List<User> getListOfUser() {

		Session session = sessionFactory.getCurrentSession();
		@SuppressWarnings("rawtypes")
		List userList = session.createCriteria(User.class).list();
		
		return userList;
	}
	
	

}
