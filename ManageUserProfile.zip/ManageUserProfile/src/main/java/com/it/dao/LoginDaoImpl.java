package com.it.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.it.model.User;

@Repository
public class LoginDaoImpl implements ILoginDao{
	
	@Autowired
	SessionFactory sessionFactory;

	@Override
	public void getUserCredentials(String username) {

		System.out.println("login dao impl "+username);
		
		Session session = sessionFactory.openSession();
		
		Query query = session.createQuery("from User where userEmail=:email");
		
		User user = (User)query.setParameter("email", username).getSingleResult();
		
		System.out.println(user.toString());
		
	}
	
	

}
