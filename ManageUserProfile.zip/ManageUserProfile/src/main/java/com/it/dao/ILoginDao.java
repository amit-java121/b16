package com.it.dao;

public interface ILoginDao {

	void getUserCredentials(String username);

}
