package com.it.dao;

import java.util.List;

import com.it.model.User;

public interface ILoginDao {

	User getUserCredentials(String username);

	String saveUserData(User user);

	List<User> getListOfUser();

	boolean deleteUserById(int id);

	User getUserById(int id);

}
