package com.it.dao;

import java.util.List;

import com.it.model.User;

public interface ILoginDao {

	User getUserCredentials(String username);

	void saveUserData(User user);

	List<User> getListOfUser();

}
