package com;

public class Bus implements Vehicle {

	@Override
	public int engine() {
		// TODO Auto-generated method stub
		
		return 2000;
	}

	@Override
	public String color() {
		// TODO Auto-generated method stub
		return "red";
	}

	@Override
	public int weels() {
		// TODO Auto-generated method stub
		return 6;
	}

	@Override
	public int speedlimit() {
		// TODO Auto-generated method stub
		return 160;
	}

	@Override
	public String modelType() {
		// TODO Auto-generated method stub
		return "top-model";
	}

}
