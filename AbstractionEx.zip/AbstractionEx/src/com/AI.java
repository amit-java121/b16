package com;

public interface AI {
	
	 void add(int a , int b);
	 void abc();

}
