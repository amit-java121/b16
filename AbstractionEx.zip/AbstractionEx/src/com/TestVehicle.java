package com;

public class TestVehicle {

	public static void main(String[] args) {
		
		Car car =  new Car();
		String color = car.color();
		System.out.println(color);
		
		Bike b = new Bike();
		System.out.println(b.color());
	}
}
