package com.abs;

public abstract class UserValidation {
	
	public String usersCreddentialsCheck(String userName,long accountNumber) {
		
		String msg = "";
		if(userName.equalsIgnoreCase("xpertit") && accountNumber == 222222222) {
			msg = "valid-user";
		}else {
			msg = "not-valid-user";
		}
		
		return msg;
		
	}
	
	public abstract String logUserActivities(String activity);

}
