package com.abs;

public class TestAbsract extends TestAbst{

	@Override
	void m1() {
		System.out.println("m1 called::");
		
	}
	
	
	public static void main(String[] args) {
		TestAbsract ta = new TestAbsract();
		ta.m1();
	}

}
