package com.abs;

public abstract class TestAbst {
	
	abstract void m1();
	
	void m2(){
		System.out.println("m2 called::");
	}
	

}
