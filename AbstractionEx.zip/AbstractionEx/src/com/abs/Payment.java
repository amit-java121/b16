package com.abs;

public class Payment extends UserValidation{
	
	public boolean withdrawn(long accountNumber, int withdrawnAmount) {
		int accountBalance = 5000;
		
		if(accountBalance > withdrawnAmount) {
			accountBalance = accountBalance-accountBalance;
			return true;
		}else {
			return false;
		}
		
	}
	
	
	public static void main(String[] args) {
		Payment p = new Payment();
		
		//user validate
		 String msg =p.usersCreddentialsCheck("xpertit", 222222222);
		 
		if(msg.equalsIgnoreCase("valid-user")) {
			
			boolean flag = p.withdrawn(2222222, 2000);
			System.out.println(flag);
			p.logUserActivities("trasaction is successful::");
		}else {
		
		p.logUserActivities("trasaction is failed::");
		}
	}


	@Override
	public String logUserActivities(String activity) {
		System.out.println("user activity logged::  "+activity);
		return "success";
	}

}
