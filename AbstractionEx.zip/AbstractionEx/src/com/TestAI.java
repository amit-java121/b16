package com;

public class TestAI implements AI{

	@Override
	public void add(int a, int b) {
	
		int sum = a+b;
		System.out.println(sum);
	}
	
	
	
	
	public static void main(String[] args) {
		TestAI ta = new TestAI();
		ta.add(10, 10);
	}




	@Override
	public void abc() {
		// TODO Auto-generated method stub
		
	}

	
}
