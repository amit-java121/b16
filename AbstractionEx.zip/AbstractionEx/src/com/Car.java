package com;

public class Car implements Vehicle{

	@Override
	public int engine() {
		// TODO Auto-generated method stub
		return 1200;
	}

	@Override
	public String color() {
		// TODO Auto-generated method stub
		return "Megma";
	}

	@Override
	public int weels() {
		// TODO Auto-generated method stub
		return 4;
	}

	@Override
	public int speedlimit() {
		// TODO Auto-generated method stub
		return 140;
	}

	@Override
	public String modelType() {
		// TODO Auto-generated method stub
		return "delta";
	}

}
