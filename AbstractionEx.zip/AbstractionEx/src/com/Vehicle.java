package com;

public interface Vehicle {
	
	public int engine();
	public String color();
	public int weels();
	public int speedlimit();
	public String modelType();

}
