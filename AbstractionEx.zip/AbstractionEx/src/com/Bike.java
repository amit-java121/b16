package com;

public class Bike implements Vehicle{

	@Override
	public int engine() {
		// TODO Auto-generated method stub
		return 150;
	}

	@Override
	public String color() {
		// TODO Auto-generated method stub
		return "black";
	}

	@Override
	public int weels() {
		// TODO Auto-generated method stub
		return 2;
	}

	@Override
	public int speedlimit() {
		// TODO Auto-generated method stub
		return 120;
	}

	@Override
	public String modelType() {
		// TODO Auto-generated method stub
		return null;
	}

}
