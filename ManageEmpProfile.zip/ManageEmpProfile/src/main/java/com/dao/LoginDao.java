package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class LoginDao {
	
	public String getUserDetailsByEmailId(String userEmail) {
		
		System.out.println("getUserDetailsByEmailId method called "+userEmail);
		String userPass = "";

		try {

			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b16", "root", "root");
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select emp_pass from employee where emp_email='"+userEmail+"'");
			
			while(rs.next()) {
				 userPass = rs.getString("emp_pass");
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return userPass;
	}

}
