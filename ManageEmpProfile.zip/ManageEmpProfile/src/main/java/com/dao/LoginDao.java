package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import com.model.Employee;

public class LoginDao {
	
	public String getUserDetailsByEmailId(String userEmail) {
		
		System.out.println("getUserDetailsByEmailId method called "+userEmail);
		String userPass = "";

		try {

			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b16", "root", "root");
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select emp_pass from employee where emp_email='"+userEmail+"'");
			
			while(rs.next()) {
				 userPass = rs.getString("emp_pass");
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return userPass;
	}

	public boolean saveEmpToDB(Employee employee) {
		boolean flag =false;
		try {

			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b16", "root", "root");
			Statement stmt = con.createStatement();
		int i = stmt.executeUpdate("insert into employee (emp_name,emp_address,emp_gender,emp_contact,emp_pass,emp_email,country) "
				+ "values('"+employee.getEmpName()+"','"+employee.getCityName()+"','"+employee.getGender()+"',"+employee.getEmpMobileNumber()+",'"+employee.getEmpPass()+"','"+employee.getEmpEmail()+"','"+employee.getCountyName()+"') ");
		if(i>0) {
			flag =true;
		}	
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return flag;
	}

}
