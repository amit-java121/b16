package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.model.Employee;

public class LoginDao {
	
	public String getUserDetailsByEmailId(String userEmail) {
		
		System.out.println("getUserDetailsByEmailId method called "+userEmail);
		String userPass = "";

		try {

			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b16", "root", "root");
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select emp_pass from employee where emp_email='"+userEmail+"'");
			
			while(rs.next()) {
				 userPass = rs.getString("emp_pass");
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return userPass;
	}

	public boolean saveEmpToDB(Employee employee) {
		boolean flag =false;
		try {

			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b16", "root", "root");
			Statement stmt = con.createStatement();
		int i = stmt.executeUpdate("insert into employee (emp_name,emp_address,emp_gender,emp_contact,emp_pass,emp_email,country) "
				+ "values('"+employee.getEmpName()+"','"+employee.getCityName()+"','"+employee.getGender()+"',"+employee.getEmpMobileNumber()+",'"+employee.getEmpPass()+"','"+employee.getEmpEmail()+"','"+employee.getCountyName()+"') ");
		if(i>0) {
			flag =true;
		}	
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return flag;
	}

	public List<Employee> getEmpAllData() {
		List<Employee> empList = new ArrayList<Employee>();
		
		try {

			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b16", "root", "root");
			Statement stmt = con.createStatement();
		     ResultSet rs = stmt.executeQuery("select * from employee");
		
		 while(rs.next()) {
			 Employee emp = new Employee();
			 emp.setEmpId(rs.getInt(1));
			 emp.setEmpName(rs.getString(2));
			 emp.setCityName(rs.getString(3));
			 emp.setGender(rs.getString(4));
			 emp.setEmpMobileNumber(rs.getLong(5));
			 emp.setEmpPass(rs.getString(6));
			 emp.setEmpEmail(rs.getString(7));
			 emp.setCountyName(rs.getString(8));
			 
			empList.add(emp);
		}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return empList;
	}

}
