package com.service;

import java.util.List;

import com.dao.LoginDao;
import com.model.Employee;

public class LoginService {
	
	public boolean checkUserCredentials(String username,String password) {
		
		System.out.println("checkUserCredentials method called"+username+" "+password);
		
		LoginDao loginDao = new LoginDao();
		String passFrmDB = loginDao.getUserDetailsByEmailId(username);
		
		if(password.equals(passFrmDB)) {
			return true;
		}
		
		return false;
	}

	public boolean saveEmployeeDetails(Employee employee) {
		 LoginDao loginDao = new LoginDao();
		 
		 return loginDao.saveEmpToDB(employee);
		
	}

	public List<Employee> getEmpAllData() {
		LoginDao loginDao = new LoginDao();
		
		return loginDao.getEmpAllData();
		
	}

}
