package com.service;

import com.dao.LoginDao;

public class LoginService {
	
	public boolean checkUserCredentials(String username,String password) {
		
		System.out.println("checkUserCredentials method called"+username+" "+password);
		
		LoginDao loginDao = new LoginDao();
		String passFrmDB = loginDao.getUserDetailsByEmailId(username);
		
		if(password.equals(passFrmDB)) {
			return true;
		}
		
		return false;
	}

}
