package com.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.Employee;
import com.service.LoginService;

/**
 * Servlet implementation class UpdateController
 */
@WebServlet("/UpdateController")
public class UpdateController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		LoginService loginService = new LoginService();
		if(request.getParameter("empEmail") != null && !request.getParameter("empEmail").isEmpty()) {
			
			Employee employee = new Employee();
			employee.setEmpName(request.getParameter("userName"));
			employee.setCityName(request.getParameter("cityName"));
			employee.setCountyName(request.getParameter("country"));
			employee.setEmpEmail(request.getParameter("empEmail"));
			employee.setGender(request.getParameter("gender"));
			employee.setEmpMobileNumber(Long.valueOf(request.getParameter("userMBNumber")));
			
			boolean flag = loginService.updateEmpDetails(employee);
			System.out.println(flag);
			if(flag) {
				List<Employee> listOfEmp = loginService.getEmpAllData();
				request.setAttribute("message", "Employee Details Updated Successfully!");
				request.setAttribute("empList", listOfEmp);
				RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
				rd.forward(request, response);
			}else {
				List<Employee> listOfEmp = loginService.getEmpAllData();
				request.setAttribute("message", "Employee details could not updated due to some issue, please try again!");
				request.setAttribute("empList", listOfEmp);
				RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
				rd.forward(request, response);
			}
			
			
		}else {
		String empId = request.getParameter("idd");
		
		
		Employee empData= loginService.getEmpDeyailsById(Integer.valueOf(empId));
		
		if(empData != null) {
			request.setAttribute("emp", empData);
			RequestDispatcher rd = request.getRequestDispatcher("update.jsp");
			rd.forward(request, response);
		}else {
			List<Employee> listOfEmp = loginService.getEmpAllData();
			request.setAttribute("empList", listOfEmp);
			request.setAttribute("message", "Employee details could not fetched due to some issue, please try again!");
			RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
			rd.forward(request, response);
		}
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
