package com.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model.Employee;
import com.service.LoginService;

/**
 * Servlet implementation class DeleteController
 */
@WebServlet("/DeleteController")
public class DeleteController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		int empId = Integer.valueOf(request.getParameter("id"));
		String empEmail = request.getParameter("empEmail");
			
			LoginService loginService = new LoginService();
			//verify user email
			HttpSession session = request.getSession(false);
			System.out.println(session.getAttribute("userEmail"));
			String adminEmail = (String)session.getAttribute("userEmail");
			boolean flag = false;
			if(adminEmail.equalsIgnoreCase(empEmail)) {
				List<Employee> listOfEmp = loginService.getEmpAllData();
				request.setAttribute("empList", listOfEmp);
				request.setAttribute("message", "You can not delete this user, because this is loggedn in user");
				RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
				rd.forward(request, response);
				 
			}else {
				flag = loginService.deleteEmpById(empId);
			}
			
			
			if(flag) {
				List<Employee> listOfEmp = loginService.getEmpAllData();
				request.setAttribute("empList", listOfEmp);
				RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
				rd.forward(request, response);
			}else {
				List<Employee> listOfEmp = loginService.getEmpAllData();
				request.setAttribute("empList", listOfEmp);
				request.setAttribute("message", "Employee could not deleted due to some issue, please try again!");
				RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
				rd.forward(request, response);
				
			}
			
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
