package com;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class WriteObjectEx {
	
	public static void main(String[] args) {
		
//		Payment payment = new Payment();
//		payment.setId(1000);
//		payment.setAccount(9199191991l);
//		payment.setCvvNo(1891);
//		payment.setCutomserName("Ajay");
		
		User user = new User(1001,1818818888l,"Bijay","xpertit","mumbai");
		
//		user.setAddress("pune");
//		user.setUserName("xpertit");
//		user.setId(1000);
//		user.setAccount(9199191991l);
//		user.setCvvNo(1891);
//		user.setCutomserName("Ajay");
		
		try {
		
		File file = new File("C:\\Users\\Amit\\Desktop\\payment-file.txt");
		
		FileOutputStream fos = new FileOutputStream(file);
		
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(user);
		
		oos.close();
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}

}
