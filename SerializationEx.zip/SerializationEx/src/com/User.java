package com;

public class User extends Payment{
	
	
	private String userName;
	private String address;

	public User(int id, long account, String cutomserName, String userName, String address) {
		super(id, account, cutomserName);
		this.userName = userName;
		this.address = address;
	}
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	

}
