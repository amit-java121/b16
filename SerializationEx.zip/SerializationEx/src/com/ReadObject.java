package com;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class ReadObject {
	
	public static void main(String[] args) {
		
		try {
			
			File file = new File("C:\\Users\\Amit\\Desktop\\payment-file.txt");
			
			FileInputStream fis = new FileInputStream(file);
			
			ObjectInputStream ois = new ObjectInputStream(fis);
			
			
			User payment = (User)ois.readObject();
			
			
			System.out.println(payment.getId());
			System.out.println(payment.getAccount());
			System.out.println(payment.getCvvNo());
			System.out.println(payment.getCutomserName());
			System.out.println(payment.getAddress());
			System.out.println(payment.getUserName());
			
			ois.close();
			
			}catch(Exception e) {
				e.printStackTrace();
			}
		
	}

}
