package com;

import java.io.Serializable;

public class Payment implements Serializable{
	
	private static final long serialVersionUID = 7979220883722309945L;
	
	private int id;
	private long account;
	private static int cvvNo;
	private transient String cutomserName;
	
	public Payment(int id, long account, String cutomserName) {
		super();
		this.id = id;
		this.account = account;
		this.cutomserName = cutomserName;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public long getAccount() {
		return account;
	}
	public void setAccount(long account) {
		this.account = account;
	}
	public int getCvvNo() {
		return cvvNo;
	}
	public void setCvvNo(int cvvNo) {
		this.cvvNo = cvvNo;
	}
	public String getCutomserName() {
		return cutomserName;
	}
	public void setCutomserName(String cutomserName) {
		this.cutomserName = cutomserName;
	}

}
