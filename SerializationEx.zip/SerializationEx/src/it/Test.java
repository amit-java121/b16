package it;

public class Test {
	
	
	@Override
	protected void finalize() throws Throwable {
		System.out.println("object removed:::");
	}
	
	public static void main(String[] args) {
		
		Test test = new Test();
		
		Test test1 = new Test();
		
		Test test2 = new Test();
		
		test1 = null;
		test2 = null;
		
		System.gc();
		
	}

}
