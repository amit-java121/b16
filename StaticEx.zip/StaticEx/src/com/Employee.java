package com;

public class Employee {
	
	int empId;
	String empName;
	int empAge;
	static String empCompanyName = "IBM";
	
	public Employee(int empId, String empName, int empAge) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empAge = empAge;
	}




	public static void main(String[] args) {
		Employee emp = new Employee(100, "xpertit", 20);
		Employee emp1 = new Employee(101, "xpertit1", 22);
		Employee emp2 = new Employee(102, "xpertit2", 23);
		
		System.out.println(emp1.empId+" "+emp1.empName+" "+emp1.empAge+" "+empCompanyName);
	}

}
