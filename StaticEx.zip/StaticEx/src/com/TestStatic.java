package com;

public class TestStatic {
	
	
	public void test() {
		
		//StaticEx se = new StaticEx();
		//System.out.println(se.aa);
		
		System.out.println(StaticEx.age);
		int age = StaticEx.age;
		System.out.println(age);
		StaticEx.m1();
		
	}
	
	
	public static void main(String[] args) {
		TestStatic ts = new TestStatic();
		ts.test();
	}

}
