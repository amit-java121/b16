package com;

public class StaticEx {
	
	static int age;
	static String name = "xpertit";
	int aa = 10;
	
	
	static {
		age = 25;
		System.out.println("static block executed::");
	}
	
	
	public static void m1() {
		age = 30;
		//aa = 100;
		StaticEx se = new StaticEx();
		System.out.println(se.aa);
		
		System.out.println("m1 method called::");
	}
	
	public void m2() {
		age = 50;
		System.out.println(age);
	}
	
	public static void main(String[] args) {
		
//		se.m1();
//		System.out.println(se.name);
//		System.out.println(se.age);
		
		System.out.println("age : "+age);
		m1();
		System.out.println(name);
		System.out.println(age);
	}

}
