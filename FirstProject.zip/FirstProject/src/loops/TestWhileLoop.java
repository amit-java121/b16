package loops;

public class TestWhileLoop {
	
	
	
	public boolean testName(boolean flag) {
		
		while(flag) {
			System.out.println(flag);
			/////logic execute
	
			flag =false;
		}
		
		return true;
	}
	
	public static void main(String[] args) {
		TestWhileLoop twl = new TestWhileLoop();
		twl.testName(true);
		
		
		
		
//		int a = 0;
//		while(a < 5) {
//			System.out.println("a "+a);
//			
//			a++;
//		}
		
	}

}
