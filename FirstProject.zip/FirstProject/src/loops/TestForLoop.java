package loops;

public class TestForLoop {
	
	public static void main(String[] args) {
		
		int[] intArray = new int[5];
		//int[] array2 = {100,200,300,400,600};
		
		intArray[0] = 10; 
		intArray[1] = 20;
		intArray[2] = 30;
		intArray[3] = 40;
		intArray[4] = 50;
		
		
		for(int i=0; i < intArray.length; i++ ) {
			
			System.out.println(intArray[i]);
		}
		
//		for(int a=0; a<=10;a++) {
//			
//			
//			System.out.println(a);
//			
//		}
		
	}

}
