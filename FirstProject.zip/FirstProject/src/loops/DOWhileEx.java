package loops;

public class DOWhileEx {
	
	
	public static void main(String[] args) {
		//int a=0;
		boolean flag = false;
		do {
			
			System.out.println("logic executed:::");
			
			flag = true;
			//a++;
		}while(flag);
		
	}

}
