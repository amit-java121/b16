package loops;

public class NestedForLoopEx {
	
	public static void main(String[] args) {
		
		aa:
		for(int i=0;i<5;i++) {
			
			System.out.println("i = "+i);
			
			bb:
			for(int j=0; j<5; j++) {
				
				
				
				if(i==3 && j==2) {
					break aa;
				}
				System.out.println("j = "+j);
			}
		}
		
	}

}
