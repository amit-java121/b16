package keywords;

public class BreakEx {

	public static void main(String[] args) {

		for (int i = 0; i < 10; i++) {

			System.out.println("before if ::" + i);

			if (i == 5) {
				continue;
			}

			System.out.println("after  if" + i);
		}

	}

}
