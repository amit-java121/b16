package conditionalStmt;

public class DateConversionEx {
	
	
	public String convertMonthName(String monthName) {
		
		String monthNum = "";
		
		switch (monthName) {
		case "JAN":
			monthNum = "01";
			break;
		case "FEB":
			monthNum = "02";
			break;
		case "MAR":
			monthNum = "03";
			break;
		case "APR":
			monthNum = "04";
			break;
		case "MAY":
			monthNum = "05";
			break;
		default:
			break;
		}
		
		return monthNum;
	}
	
	
	public static void main(String[] args) {
		DateConversionEx dce = new DateConversionEx();
	
		String date = "10-FEB-2020";
		String monthName = date.substring(3, 6);
		//System.out.println(monthName);

		String monthnumber = dce.convertMonthName(monthName);
		//System.out.println(monthnumber);
		//output // 10-01-2020
		String newDate = date.replace(monthName, monthnumber);
		System.out.println("formatted date:: "+newDate);
	}

}
