package conditionalStmt;

public class IfElseEx {
	
	public void m1(int a) {
		
		System.out.println("before if:::");
		if(a > 10) {
			System.out.println("outer if called:::");
			
			int b = a+20;
			
			if(b > 25) {
				
				System.out.println("inner if");
				
			}else {
				System.out.println("inner else");
			}
			
		}else {
			System.out.println("else called:::");
		}
		
		System.out.println("after if:::");
	}
	
	public static void main(String[] args) {
		IfElseEx iff = new IfElseEx();
		iff.m1(5);
	}

}
