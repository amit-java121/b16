package conditionalStmt;

public class IfElseIfEx {
	
	public void m2(int num) {
		
		if(num == 10) {
			System.out.println(" number is "+num);
		}else if(num == 20) {
			System.out.println(" number is "+num);
		}else if(num == 30) {
			System.out.println(" number is "+num);
		}else if(num == 40 ) {
			System.out.println(" number is "+num);
		}else {
			System.out.println("else ::");
		}
		
	}
	
	public static void main(String[] args) {
		IfElseIfEx ife = new IfElseIfEx();
		ife.m2(50);
	}

}
