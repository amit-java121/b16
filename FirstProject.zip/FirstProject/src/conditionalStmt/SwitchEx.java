package conditionalStmt;

public class SwitchEx {
	
	public void testSwitch(int num) {
		
		
		switch (num) {
		case 10:
			System.out.println("number is "+num);
			break;
			
		case 20:
			System.out.println("number is "+num);
			break;
		case 30:
			System.out.println("number is "+num);
			break;
		case 40:
			System.out.println("number is "+num);
	    break;
	    
		default:
			System.out.println("default executed::");
		}
		
	}
	
	public static void main(String[] args) {
		SwitchEx se = new SwitchEx();
		se.testSwitch(30);
	}

}
