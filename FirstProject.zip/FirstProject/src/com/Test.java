package com;

public class Test {
	
	public int add(int a,int b) {
		int sum = a+b;
		
		return sum;
	}

}
