package com;

public class Test2 {
	
	public int multiply(int m) {
		
		Test t = new Test();
		int sum = t.add(10, 20);
		int mul = sum*m;
		
		return mul;
	}
	
	
	public static void main(String[] args) {
		Test2 test = new Test2();
		int multiply =test.multiply(100);
		System.out.println(multiply);
	}

}
