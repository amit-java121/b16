
public class Test {
	
	int age = 25;
	
	public void printAge() {
		System.out.println(age);
	}
	
	public static void main12(String[] args) {
		
		
		Test test = new Test();
		test.printAge();
		
		System.out.println("helloooooo:::");
	}
}
