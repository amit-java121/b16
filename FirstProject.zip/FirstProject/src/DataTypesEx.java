
public class DataTypesEx {

	int aa;
	char c;
	boolean flag;
	float f;
	double d;
	long l;
	
	public static void main(String[] args) {
		DataTypesEx d = new DataTypesEx();
		
		System.out.println(d.aa);
		System.out.println(d.c);
		System.out.println(d.flag);
		System.out.println(d.f);
		System.out.println(d.d);
		System.out.println(d.l);
		
	}
}
