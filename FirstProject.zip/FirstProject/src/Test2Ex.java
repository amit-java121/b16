
public class Test2Ex {
	
	public int add(int a,int b) {
		
		int sum = a+b;
		//System.out.println("sum "+sum);
		return sum;
	}

	
	public static void main(String[] args) {
		
		Test2Ex test = new Test2Ex();
		int summ = test.add(10, 20);
		System.out.println(summ);
		
	}
}
