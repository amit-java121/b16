package pkg;

import practice.TestMethods;

public class TestMethods2 {
	
	public static void main(String[] args) {
		
		TestMethods tm = new TestMethods();
		int[] array = tm.prepareData();
	
		for(int ar:array) {
			System.out.println(ar);
		}
	
	}
	

}
