package pkg;

public class TestMethods3 {

	public void test() {

		System.out.println("test method called");
		test1();
	}

	public void test1() {

		System.out.println("test1 method called");
		test2();
	}

	public void test2() {
		System.out.println("test2 method called");
	}

	public static void main(String[] args) {
		TestMethods3 tm3 = new TestMethods3();
		tm3.test();
	}

}
