
public class MethodTest {
	
	public void m1() {
		System.out.println("m1 called:::");
		
		//return 100;
	}
	
	public void m2() {
	  m1();
	 // int num2 = num+200;
		System.out.println("m2 called::: ");
	}

	public static void main(String[] args) {
		MethodTest mt = new MethodTest();
		mt.m2();
	}
}
