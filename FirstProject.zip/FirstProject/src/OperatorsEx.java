
public class OperatorsEx {
	
	
	public static void main(String[] args) {
		
		
//		int a =10;
//		System.out.println(a);//10
//		System.out.println(a++);//11//10
//		System.out.println(a);//10/11
//		System.out.println(++a);//12//11
//		System.out.println(a);//12
		
//		int a =10;
//		int b =20;
//		int sum = b/a;
//		System.out.println(sum);
		
		
//		
//		if(aa == bb) {
//			System.out.println("if called::");
//		}
//		
//		System.out.println("after if condition::");
		
		boolean flag= true;
		boolean flag2 = false;
		
		int aa =10;
		int bb = 12;
		int cc = 30;
		
		//System.out.println(aa < bb);
		//System.out.println(bb > cc);
//		if(aa > bb || bb < cc) {
//			
//			
//			System.out.println("inside if ::");
//		}
		
//		if(flag && flag2) {
//			System.out.println("second if::");
//		}
		
		
//		if(aa > bb | bb < cc) {
//			
//			
//			System.out.println("inside if ::");
//		}
		
		
//		int d =10;
//		System.out.println(d);
//		d =20;
//		System.out.println(d);
		
		int age1 =25;
		int age2 = 30;
		
		int age3;
		if(age1 > age2) {
			age3 = 50;
		}else {
			age3 = 100;
		}
		
		System.out.println(age3);
		
		//System.out.println(age1 > age2 ? 50 : 100);
		
	}

}
