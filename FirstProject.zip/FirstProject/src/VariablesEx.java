
public class VariablesEx {
	
	int aa =10;
	static int age = 25;
	
	public void test() {
		int a =10;
		int b =20;
	}

	
	public static void test2() {
		VariablesEx v = new VariablesEx();
		System.out.println(v.aa);
		System.out.println(age);
	}
	
	public static void main(String[] args) {
		VariablesEx ve = new VariablesEx();
		ve.test2();
		System.out.println(age);
	}
}
