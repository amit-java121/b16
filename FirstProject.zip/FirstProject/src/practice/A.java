package practice;

public class A {
	
	
	public String[] dataPrepare() {
		
		String[] empData = new String[5];
		empData[0] = "Ajay";
		empData[1] = "Bijay";
		empData[2] = "Sanjay";
		empData[3] = "Vijay";
		empData[4] = "xpertit";
		
		return empData;
	}

}
