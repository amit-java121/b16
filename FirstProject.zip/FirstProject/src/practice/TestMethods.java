package practice;

public class TestMethods {
	
	
	public int[] prepareData() {
		
		int[] intArray = {10,20,30,30,40,50,50,50,60,90,100};
		
		return intArray;
	}
	
	public int filterData(int number) {
		
		int count = 0;
		
		int[] array = prepareData();
		
		for(int i=0; i<array.length; i++) {
			
			int valuefrmarray = array[i];
			
			if(number == valuefrmarray) {
				count++;
				
			}
			
		}
		
		return count;
	}
	
	public static void test() {
		
	}
	
	public static void main(String[] args) {
		TestMethods tm = new TestMethods();
		int count = tm.filterData(500);
		System.out.println("number of occurances :: "+count);
		test();
	}

}
