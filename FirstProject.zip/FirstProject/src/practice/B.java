package practice;

public class B {
	
	public String getEmpData(String empName) {
		
		A a = new A();
		String[] empNames = a.dataPrepare();
		
		String msg = "";
		
		for(int i=0;i<empNames.length;i++) {
			
			String nameFrmArray = empNames[i];
			
			if(empName.equalsIgnoreCase(nameFrmArray)) {
				msg = "This name is present";
				break;
				
			}else {
				msg = "This name is not present";
			}
			
		}
		
		return msg;
	}

}
