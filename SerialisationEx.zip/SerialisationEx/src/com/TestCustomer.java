package com;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class TestCustomer {
	
	
		public void readPaymentData() {
		
		try {
			FileInputStream fis = new FileInputStream("C:\\Users\\Amit\\Desktop\\test.txt");
			
			ObjectInputStream ois = new ObjectInputStream(fis);
			
			Customer customer = (Customer)ois.readObject();
			
			System.out.println(customer.getBankName());
			System.out.println(customer.getCardNumber());
			System.out.println(customer.getCustName());
			System.out.println(customer.getCvvNo());
			
			System.out.println(customer.getCustomerId());
			System.out.println(customer.getCustomerName());
			
			
			System.out.println(customer.getCustomerAddress());
			
			}catch(Exception e) {
				e.printStackTrace();
			}
		
	}

	
	public static void main(String[] args) {

		
		Customer customer = new Customer(1414414141, "Anuj", "HDFC BANK", 1234,1111111,"Ajay","pune");
		//Paymnet paymnet = new Paymnet(1414414141, "Anuj", "HDFC BANK", 1234);
		try {
		FileOutputStream fos = new FileOutputStream("C:\\Users\\Amit\\Desktop\\test.txt");
		
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(customer);
		
		oos.close();
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
		
//		TestCustomer cust = new TestCustomer();
//		cust.readPaymentData();
//		
	}
}
