package com;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class HdfcBank {
	
	
	public void readPaymentData() {
		
		try {
			FileInputStream fis = new FileInputStream("C:\\Users\\Amit\\Desktop\\test.txt");
			
			ObjectInputStream ois = new ObjectInputStream(fis);
			
			Paymnet payment = (Paymnet)ois.readObject();
			
			System.out.println(payment.getCardNumber());
			System.out.println(payment.getBankName());
			System.out.println(payment.getCustomerName());
			System.out.println(payment.getCvvNo());
			
			}catch(Exception e) {
				e.printStackTrace();
			}
		
	}
	
	
	public static void main(String[] args) {
		

		
//		Paymnet paymnet = new Paymnet(1414414141, "Anuj", "HDFC BANK", 1234);
//		try {
//		FileOutputStream fos = new FileOutputStream("C:\\Users\\Amit\\Desktop\\test.txt");
//		
//		ObjectOutputStream oos = new ObjectOutputStream(fos);
//		oos.writeObject(paymnet);
//		
//		oos.close();
//		
//		}catch(Exception e) {
//			e.printStackTrace();
//		}
		
		
		HdfcBank bank = new HdfcBank();
		bank.readPaymentData();
		
	}

}
