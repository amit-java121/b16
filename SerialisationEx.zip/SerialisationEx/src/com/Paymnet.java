package com;

import java.io.Serializable;

public class Paymnet{
	
	
	private static final long serialVersionUID = -1726555539749023147L;
	
	private int cardNumber;
	private String customerName;
	private transient String bankName;
	private static int cvvNo;
	
	
	public Paymnet(int cardNumber, String customerName, String bankName, int cvvNo) {
		super();
		this.cardNumber = cardNumber;
		this.customerName = customerName;
		this.bankName = bankName;
		this.cvvNo = cvvNo;
	}
	public int getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(int cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public int getCvvNo() {
		return cvvNo;
	}
	public void setCvvNo(int cvvNo) {
		this.cvvNo = cvvNo;
	}
	
	

}
