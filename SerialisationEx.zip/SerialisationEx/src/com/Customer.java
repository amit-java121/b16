package com;

import java.io.Serializable;

public class Customer extends Paymnet{

	
	private int customerId;
	private String custName;
	private static String customerAddress;
	
	
	public Customer(int cardNumber, String customerName, String bankName, int cvvNo, int customerId,
			String customerName2,String customerAddress) {
		super(cardNumber, customerName, bankName, cvvNo);
		this.customerId = customerId;
		this.custName = customerName2;
		this.customerAddress = customerAddress;
	}
	
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public static String getCustomerAddress() {
		return customerAddress;
	}

	public static void setCustomerAddress(String customerAddress) {
		Customer.customerAddress = customerAddress;
	}
	
	
	

}
