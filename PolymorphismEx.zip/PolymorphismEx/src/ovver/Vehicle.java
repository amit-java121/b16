package ovver;

public class Vehicle {
	
	public void run() {
		
		System.out.println("running...");
		
	}
	
	public void engine() {
		
		System.out.println("engine...");
		
	}

}
