package ovver;

public class B extends A{
	
	
	public void m5(int a) {
		System.out.println("m1 called form class B");
	}

	public static void main(String[] args) {
//		B b = new B();
//		b.m1(10);
//		b.m1("xpertit");
		
		B b = new B();
		A a = new A();
		A a1 = new B();
		
		//B b = new A();
	}
}
