package ovver;

public class Car extends Vehicle{
	
	public void run() {
		System.out.println("car is running...");
	}

}
