package ovver;

public class A {
	
	public void m1(String na) {
		System.out.println("m1 called form class A");
	}
	
	public void m1(int a) {
		System.out.println("m1 with int param class A");
	}

}
