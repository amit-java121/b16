package ovver;

public class Bike extends Vehicle{
	
	public void run() {
		System.out.println("bike is running..");
	}
	
	public static void main(String[] args) {
		
	}

}
