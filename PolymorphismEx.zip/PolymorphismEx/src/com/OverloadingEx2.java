package com;

public class OverloadingEx2 {
	
	public void addition(int a,long b) {
		long sum = a+b;
		System.out.println("int "+sum);
		
	}
	
	public void addition(long a,int b) {
		long sum = a+b;
		System.out.println("long: "+sum);
		
	}

	
	public static void main(String[] args) {
		OverloadingEx2 oe = new OverloadingEx2();
		//oe.addition(10, 20);
		
	}

}
