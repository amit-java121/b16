package com;

public class OverloadingEx {
	
	public void addition(int a,int b) {
		int sum = a+b;
		System.out.println(sum);
		
	}
	
	public void addition(int a,int b,int c) {
		int sum = a+b+c;
		System.out.println(sum);
		
	}
	
	public void xyz(int a,int b,int c) {
		int sum = a+b+c;
		System.out.println(sum);
		
	}
	
	
	public static void main(String[] args) {
		OverloadingEx oe = new OverloadingEx();
		oe.addition(10, 20);
		oe.xyz(10, 20, 30);
	}

}
