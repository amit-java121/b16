package sorting;

public class Employee{
	
	private long adhaarNumber;
	private String userName;
	private int age;
	private String gender;
	private String cityName;
	
	public long getAdhaarNumber() {
		return adhaarNumber;
	}
	public void setAdhaarNumber(long adhaarNumber) {
		this.adhaarNumber = adhaarNumber;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	
	@Override
	public String toString() {
		return "User [adhaarNumber=" + adhaarNumber + ", userName=" + userName + ", age=" + age + ", gender=" + gender
				+ ", cityName=" + cityName + "]";
	}	

}
