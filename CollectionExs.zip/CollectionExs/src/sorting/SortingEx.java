package sorting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import map.User;

public class SortingEx {
	
	public static void main(String[] args) {
		
//		List<String> list = new ArrayList<>();
//		list.add("Bijay");
//		list.add("Promod");
//		list.add("Sachin");
//		list.add("Ajay");
//		
//		Collections.sort(list);
//		
//		System.out.println(list);
		
		
		Customer user = new Customer();
		user.setAdhaarNumber(101001004);
		user.setAge(25);
		user.setGender("male");
		user.setCityName("pune");
		user.setUserName("Sunil");
		
		Customer user1 = new Customer();
		user1.setAdhaarNumber(101001001);
		user1.setAge(25);
		user1.setGender("male");
		user1.setCityName("pune");
		user1.setUserName("Ajay");
		
		
		Customer user2 = new Customer();
		user2.setAdhaarNumber(101001002);
		user2.setAge(25);
		user2.setGender("male");
		user2.setCityName("nagpur");
		user2.setUserName("Bijay");
		
		Customer user3 = new Customer();
		user3.setAdhaarNumber(101001003);
		user3.setAge(25);
		user3.setGender("male");
		user3.setCityName("mumbai");
		user3.setUserName("Rohit");
		
		List<Customer> userList = new ArrayList<Customer>();
		
		userList.add(user);
		
		userList.add(user1);
		userList.add(user2);
		userList.add(user3);
		
		System.out.println("unsorted::"+userList);
		
		Collections.sort(userList);
		
		System.out.println("sorted objects: "+userList);

		
	}

}
