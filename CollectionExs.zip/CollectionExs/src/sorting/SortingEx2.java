package sorting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SortingEx2 {
	
	public static void main(String[] args) {
		
		Employee user = new Employee();
		user.setAdhaarNumber(101001004);
		user.setAge(25);
		user.setGender("male");
		user.setCityName("pune");
		user.setUserName("Sunil");
		
		Employee user1 = new Employee();
		user1.setAdhaarNumber(101001001);
		user1.setAge(25);
		user1.setGender("male");
		user1.setCityName("pune");
		user1.setUserName("Ajay");
		
		
		Employee user2 = new Employee();
		user2.setAdhaarNumber(101001002);
		user2.setAge(25);
		user2.setGender("male");
		user2.setCityName("nagpur");
		user2.setUserName("Bijay");
		
		Employee user3 = new Employee();
		user3.setAdhaarNumber(101001003);
		user3.setAge(25);
		user3.setGender("male");
		user3.setCityName("mumbai");
		user3.setUserName("Rohit");
		
		List<Employee> userList = new ArrayList<Employee>();
		
		userList.add(user);
		
		userList.add(user1);
		userList.add(user2);
		userList.add(user3);
		
		System.out.println("unsorted::"+userList);
		
		Collections.sort(userList, new AdhaarNumberComprator());
		
		System.out.println("sorted on Adhaar Number: "+userList);
		
		
		Collections.sort(userList, new CityNameComprator());
		
		System.out.println("sorted on city: "+userList);

		
	}

}
