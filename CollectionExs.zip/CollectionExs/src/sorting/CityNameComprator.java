package sorting;

import java.util.Comparator;

public class CityNameComprator implements Comparator<Employee>{

	@Override
	public int compare(Employee o1, Employee o2) {
		
		return o1.getCityName().compareTo(o2.getCityName());
	}

}
