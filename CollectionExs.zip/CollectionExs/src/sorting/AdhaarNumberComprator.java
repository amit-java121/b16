package sorting;

import java.util.Comparator;

public class AdhaarNumberComprator implements Comparator<Employee>{

	@Override
	public int compare(Employee o1, Employee o2) {
		
		if(o1.getAdhaarNumber() > o2.getAdhaarNumber()) {
			return 1;
		}else if(o1.getAdhaarNumber() < o2.getAdhaarNumber()) {
			return -1;
		}
		return 0;
	}

}
