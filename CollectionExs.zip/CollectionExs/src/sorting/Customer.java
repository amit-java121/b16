package sorting;

public class Customer implements Comparable<Customer>{
	
	private long adhaarNumber;
	private String userName;
	private int age;
	private String gender;
	private String cityName;
	
	public long getAdhaarNumber() {
		return adhaarNumber;
	}
	public void setAdhaarNumber(long adhaarNumber) {
		this.adhaarNumber = adhaarNumber;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	
	@Override
	public String toString() {
		return "User [adhaarNumber=" + adhaarNumber + ", userName=" + userName + ", age=" + age + ", gender=" + gender
				+ ", cityName=" + cityName + "]";
	}
//	
//	@Override
//	public int compareTo(Customer user) {
//		
//		if(user.getAdhaarNumber() < adhaarNumber) {
//			return 1;
//		}else if(user.getAdhaarNumber() > adhaarNumber) {
//			return -1;
//		}else {
//			return 0;
//		}
//		
//	}
	@Override
	public int compareTo(Customer customer) {
		
		return userName.compareTo(customer.getUserName());
	}
	

}
