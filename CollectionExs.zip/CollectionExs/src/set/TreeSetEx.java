package set;

import java.util.NavigableSet;
import java.util.TreeSet;

public class TreeSetEx {
	
	public static void main(String[] args) {
		
		TreeSet<String> treeSet = new TreeSet<>();
		treeSet.add("pqr");
		treeSet.add("sunil");
		treeSet.add("pramod");
		treeSet.add("xpertit");
		treeSet.add("pqr");
		treeSet.add(null);
		
		System.out.println(treeSet);
		
		NavigableSet<String> reverseOrderedSet = treeSet.descendingSet();
		
		System.out.println(reverseOrderedSet);
		
	}

}
