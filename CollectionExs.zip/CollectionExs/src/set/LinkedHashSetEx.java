package set;

import java.util.HashSet;
import java.util.LinkedHashSet;

public class LinkedHashSetEx {
	public static void main(String[] args) {
		
		LinkedHashSet<String> linkedSet = new LinkedHashSet<>();
		linkedSet.add("pqr");
		linkedSet.add("Sunil");
		linkedSet.add("pramod");
		linkedSet.add("xpertit");
		linkedSet.add("pqr");
		
		System.out.println(linkedSet);
		
	}

}
