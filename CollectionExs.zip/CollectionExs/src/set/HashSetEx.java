package set;

import java.util.HashSet;

public class HashSetEx {

	
	public static void main(String[] args) {
		
		HashSet<String> hashSet = new HashSet<>();
		hashSet.add("pqr");
		hashSet.add("Sunil");
		hashSet.add("pramod");
		hashSet.add("xpertit");
		hashSet.add("pqr");
		System.out.println(hashSet);
		
	}
}
