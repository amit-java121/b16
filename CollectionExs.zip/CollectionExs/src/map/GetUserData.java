package map;

import java.util.HashMap;
import java.util.Map.Entry;

public class GetUserData {
	
	public static void main(String[] args) {
		
		UserDataBase udb = new UserDataBase();
		HashMap<Long, User> hashMap = udb.prepareUserData();
		
		System.out.println(hashMap.get(101001003l));
		
		for(Entry<Long, User> userMap:hashMap.entrySet()) {
			System.out.println(userMap.toString());
		}
	}

}
