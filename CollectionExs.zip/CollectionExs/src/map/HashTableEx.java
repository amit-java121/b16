package map;

import java.util.Hashtable;

public class HashTableEx {
	
	public static void main(String[] args) {
		Hashtable<Integer, String> hashTable = new Hashtable<>();
		hashTable.put(1000, "Ajay");
		hashTable.put(1003, "Ajay2");
		hashTable.put(1004, "Ajay1");
		hashTable.put(1001, "Bijay");
		hashTable.put(1005, "abc");
		
		System.out.println(hashTable);
	
	}

}
