package map;

import java.util.HashMap;

public class UserDataBase {

	public HashMap<Long, User> prepareUserData() {
		
		User user = new User();
		user.setAdhaarNumber(101001001);
		user.setAge(25);
		user.setGender("male");
		user.setCityName("pune");
		user.setUserName("Sunil1");
		
		User user1 = new User();
		user1.setAdhaarNumber(101001002);
		user1.setAge(25);
		user1.setGender("male");
		user1.setCityName("pune");
		user1.setUserName("Sunil2");
		
		
		User user2 = new User();
		user2.setAdhaarNumber(101001003);
		user2.setAge(25);
		user2.setGender("male");
		user2.setCityName("nagpur");
		user2.setUserName("Sunil3");
		
		User user3 = new User();
		user3.setAdhaarNumber(101001004);
		user3.setAge(25);
		user3.setGender("male");
		user3.setCityName("mumbai");
		user3.setUserName("Sunil4");
		
		HashMap<Long, User> hashMap = new HashMap<Long, User>();
		
		hashMap.put(user.getAdhaarNumber(), user);
		
		hashMap.put(user1.getAdhaarNumber(), user1);
		hashMap.put(user2.getAdhaarNumber(), user2);
		hashMap.put(user3.getAdhaarNumber(), user3);
		
		return hashMap;
	}
}
