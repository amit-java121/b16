package map;

import java.util.HashMap;
import java.util.Map.Entry;

public class HashMapEx {
	
	public static void main(String[] args) {
		
		HashMap<Integer, String> hashMap = new HashMap<>();
		
		hashMap.put(1000, "Sunil");
		hashMap.put(1001, "Sunil1");
		hashMap.put(1002, "Sunil2");
		hashMap.put(1003, "Sunil3");
		hashMap.put(1004, null);
		
		
		System.out.println(hashMap.size());
		
		//System.out.println(hashMap);
		
		for(Entry<Integer, String> map:hashMap.entrySet()) {
			System.out.println(map.getKey()+" "+map.getValue());
		}
		
		//System.out.println(hashMap.get(1003));
		
		//System.out.println(hashMap.containsKey(1001));
		System.out.println(hashMap.getOrDefault(1003, "hello"));
		
		System.out.println(hashMap.keySet());
		System.out.println(hashMap.values());
		
		
	}

}
