package map;

import java.util.TreeMap;

public class TreeMapEx {
	
	public static void main(String[] args) {
		
		TreeMap<Integer, String> treeMap = new TreeMap<>();
		treeMap.put(1003, "abc");
		treeMap.put(1002, "xyz");
		treeMap.put(1000, "abc1");
		treeMap.put(1003, null);
		
		System.out.println(treeMap);
		
	}

}
