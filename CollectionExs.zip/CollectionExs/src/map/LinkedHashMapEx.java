package map;

import java.util.LinkedHashMap;

public class LinkedHashMapEx {
	
	public static void main(String[] args) {
		
		LinkedHashMap<String, Integer> linkedHashMap = new LinkedHashMap<>();
		
		linkedHashMap.put("pqr", 100012);
		linkedHashMap.put("abc", 100010);
		linkedHashMap.put("xyz", 100011);
		
		
		System.out.println(linkedHashMap);
		
	}

}
