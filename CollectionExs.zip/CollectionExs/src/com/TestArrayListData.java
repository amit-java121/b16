package com;

import java.util.ArrayList;

public class TestArrayListData {
	
	public static void main(String[] args) {
		ArrayListEx al = new ArrayListEx();
		ArrayList list = al.setData();
		
		for(int i =0;i<list.size();i++) {
		 System.out.println(list.get(i));
	}}

}
