package com;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ArrayListEx2 {
	
	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<String>();
		list.add("Sunil");
		list.add("Ajay");
		list.add("Bijay");
		list.add("Raju");
		list.add("Sunil");
		
		//System.out.println(list.size());
		
		List<String> secondList = new ArrayList<>();
		secondList.add("xyz");
		secondList.add("pqr");
		secondList.add("abc");
		
		
		System.out.println(list.addAll(secondList));
		//System.out.println(list.addAll(3, secondList));
		
		//System.out.println(list.contains("Bijay"));
		
		//System.out.println(list.containsAll(secondList));
		
		//System.out.println(list.equals("Ajay"));
		
		for(String li:list) {
		
			if(li.equals("Ajay")) {
				System.out.println("Name found");
			}
		}
		
		
		//System.out.println(list.get(3));
		
		//System.out.println(list.indexOf("Raju"));
		
		//System.out.println(list.isEmpty());
		
		//System.out.println(list.lastIndexOf("Sunil"));
		//System.out.println(list.removeAll(secondList));
		//System.out.println(list.remove(10));
		//System.out.println(list.removeIf());
		
		 // list.removeIf(a->a.equals("Sunil"));
		  
		 // System.out.println(list.retainAll(secondList));
		
//		Iterator<String> itr = list.iterator();
//		while(itr.hasNext()) {
//			System.out.println(itr.next());
//		}
		List<String> subList = list.subList(4, 8);
		System.out.println(subList);
		
		list.clear();
		System.out.println(list.size());
//		
//		for(int i=0;i<list.size();i++) {
//			String name = (String)list.get(i);
//			System.out.println(name);
//		}
		
	}

}
