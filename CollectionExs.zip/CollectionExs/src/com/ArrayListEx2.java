package com;

import java.util.ArrayList;

public class ArrayListEx2 {
	
	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<String>();
		list.add("Sunil");
		list.add("Ajay");
		list.add("Bijay");
		list.add("Raju");
		list.add("Sunil");
		//list.add(100);
		
		for(int i=0;i<list.size();i++) {
			String name = (String)list.get(i);
			System.out.println(name);
		}
		
	}

}
