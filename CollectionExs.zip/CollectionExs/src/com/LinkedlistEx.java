package com;

import java.util.LinkedList;

public class LinkedlistEx {
	
	public static void main(String[] args) {
		LinkedList<String> linkedList = new LinkedList<>();
		
	}

}
