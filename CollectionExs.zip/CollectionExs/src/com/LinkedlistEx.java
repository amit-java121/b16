package com;

import java.util.LinkedList;

public class LinkedlistEx {
	
	public static void main(String[] args) {
		LinkedList<String> linkedList = new LinkedList<>();
		
		linkedList.add("Promod");
		linkedList.addFirst("abc");
		linkedList.add("Sunil");
		linkedList.add("Xpertit");
		
		linkedList.addLast("pqr");		
		System.out.println(linkedList);
		
	}

}
