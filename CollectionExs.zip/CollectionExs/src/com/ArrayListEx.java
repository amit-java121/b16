package com;

import java.util.ArrayList;

public class ArrayListEx {
	
	ArrayList setData() {
		
		ArrayList<Employee> list = new ArrayList<Employee>();
		
		Employee emp = new Employee();
		emp.setEmpId(100);
		emp.setEmpName("Sunil");
		emp.setEmpAddress("pune");
		emp.setMobileNumber(1010010010);
		
		Employee emp2 = new Employee();
		emp2.setEmpId(101);
		emp2.setEmpName("Ajay");
		emp2.setEmpAddress("mumbai");
		emp2.setMobileNumber(414144411187l);
		
		Employee emp3 = new Employee();
		emp3.setEmpId(102);
		emp3.setEmpName("Bijay");
		emp3.setEmpAddress("pune");
		emp3.setMobileNumber(716616616661l);
		
		
		list.add(emp);
		list.add(emp2);
		list.add(emp3);
		
		
//		list.add("Sunil");
//		list.add("xpertit");
//		list.add(100);
//		list.add("xyz");
		
		return list;
	}


}
