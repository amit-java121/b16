package com;

import java.util.Vector;

public class VectorEx {
	
	public static void main(String[] args) {
		
		Vector<String> vector = new Vector<>();
		vector.add("abc");
		vector.addElement("xyz");
		vector.addElement("pqr");
		
		//System.out.println(vector.firstElement());
		//System.out.println(vector.lastElement());
		//System.out.println(vector.removeElement("pqr"));
		vector.removeElementAt(1);
		
		System.out.println(vector);
		
	}

}
