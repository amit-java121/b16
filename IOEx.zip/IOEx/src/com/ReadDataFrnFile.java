package com;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;

public class ReadDataFrnFile {
	
	
	public static void main(String[] args) throws Exception {
		
		String str = "welcome to input ouput...123";
		
//		File file = new File("C:\\Users\\Amit\\Desktop\\data.txt");
//		
//		FileOutputStream fos = new FileOutputStream(file);
//		
//		fos.write(str.getBytes());
//		
//		fos.close();
		
		FileWriter fw = new FileWriter("C:\\Users\\Amit\\Desktop\\data.txt",true);
		fw.write("\n"+str);
		fw.close();
		//read
		
//		FileInputStream fis = new FileInputStream("C:\\Users\\Amit\\Desktop\\data.txt");
//		//int i = fis.read();
//		int i;
//		
//		while( (i = fis.read()) != -1) {
//			System.out.print((char)i);
//		}
//		
//		fis.close();
		
		
	}

}
