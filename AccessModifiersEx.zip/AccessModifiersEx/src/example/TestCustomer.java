package example;

public class TestCustomer {
	
	public static void main(String[] args) {
		Customer customer = new Customer();
		float totalAmount= customer.intrestCalculation(10000, 12, 5);
		System.out.println("total amount "+totalAmount);
	}

}
