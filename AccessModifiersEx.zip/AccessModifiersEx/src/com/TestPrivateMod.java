package com;

public class TestPrivateMod {
	
	public static void main(String[] args) {
		Customer c = new Customer();
		UserDefaultEx udd = new UserDefaultEx();
		ProtectedEx pe = new ProtectedEx();
		
	}

}
